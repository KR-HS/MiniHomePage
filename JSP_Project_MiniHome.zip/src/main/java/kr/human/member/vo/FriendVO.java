package kr.human.member.vo;

import lombok.Data;

@Data
public class FriendVO {
	private int idx;
	private String userid;
	private String friendid;
}
